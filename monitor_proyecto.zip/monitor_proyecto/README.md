\# Monitor del Sistema - Django + Psutil



\## Descripción

Aplicación web desarrollada con Django que muestra en tiempo real el estado del sistema usando la librería `psutil`.



\## Requisitos

\- Python 3.x

\- Django

\- Psutil



\## Instalación

```bash

git clone <repositorio>

cd monitor

python -m venv venv

source venv/bin/activate  # o venv\\Scripts\\activate en Windows

pip install -r requirements.txt

python manage.py runserver

# 

