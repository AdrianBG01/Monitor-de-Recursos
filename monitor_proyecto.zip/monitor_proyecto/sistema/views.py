# views.py placeholder
import psutil
import platform
from django.shortcuts import render

def sistema_info(request):
    try:
        cpu = psutil.cpu_percent(interval=1)
        memoria = psutil.virtual_memory()
        disco = psutil.disk_usage('/')
        sistema_operativo = platform.system()
        nucleos = psutil.cpu_count()

        context = {
            'cpu': cpu,
            'memoria_total': round(memoria.total / (1024**3), 2),
            'memoria_usada': round(memoria.used / (1024**3), 2),
            'memoria_porcentaje': memoria.percent,
            'disco_total': round(disco.total / (1024**3), 2),
            'disco_usado': round(disco.used / (1024**3), 2),
            'disco_libre': round(disco.free / (1024**3), 2),
            'disco_porcentaje': disco.percent,
            'so': sistema_operativo,
            'nucleos': nucleos,
        }
    except Exception as e:
        context = {'error': str(e)}
    
    return render(request, 'sistema/index.html', context)
